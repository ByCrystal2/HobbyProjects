﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _15102023_RandomCharFinding_FGG
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(GetUserValue());

            Console.ReadKey();
        }

        public static List<int> RandomCharMaker()
        {
            List<int> list = new List<int>(100);
            List<char> list2 = new List<char>(100);

            for (int i = 0; i < list.Capacity; i++)
            {
                list.Add(0);
            }
            for (int i = 0; i < list2.Capacity; i++)
            {
                list2.Add(Convert.ToChar(i));
            }

            Random r = new Random();
            int randomChar = list2[r.Next(0, list2.Count-1)];

            int randomListIndex = r.Next(0, list.Capacity);
            list[randomListIndex] = randomChar;

            return list;
        }

        public static string GetUserValue()
        {
            List<int> currentList = RandomCharMaker();
            Console.WriteLine("Lütfen doğru karakterin hangi hücrede olduğunu tahmin edin: ");
            int value = int.Parse(Console.ReadLine());

            string message;
            if (currentList[value] > 0)
            {
                message = "Tebrikler doğru bildiniz!";
            }
            else
            {
                message = "Yanlış bildiniz!";
            }
            return message;

        }
    }
}
