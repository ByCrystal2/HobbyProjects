﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    public  class Test
    {
        public int para { get; set; }// Dışarıdan erişilemez ve miras alınan bir classtan erişilebilinir.
    }
    public class Test2 : Test
    {
        public void Init()
        {
            Cocuk1 cocuk1 = new Cocuk1();
            cocuk1.para = 0;
            Cocuk2 cocuk2 = new Cocuk2();
            cocuk1.para = 0;

        cocuk1.Sevgi();
        cocuk2.Sevgi();

        ErkekBebek newBebek = new ErkekBebek();
        newBebek.YemekSaatiGeldi();
        ErkekBebek newBebek2 = new ErkekBebek();
        newBebek.YemekSaatiGeldi();
        newBebek.Sevgi();

    }
    }
    public abstract class Anne
    {
    public int para { get; set; }
    public abstract Color EyeColor { get; set; }
    public abstract void Kızmak();
        public virtual string Sevgi()
        {
            switch (para)
            {
                case <=100:
                    return "Git başımdan";
                case <=200:
                    return "Kafa okşama";
                    case >=500:
                    return "Seni seviyorummmm";
                default:
                    return "sg";
            }
        }
        public void YemekSaatiGeldi()
        {
            // bebeği doyurman lazım
        }
    }
public class Cocuk1 : Anne
{
    public override Color EyeColor { 
        get => Color.Blue; 
        set => throw new NotImplementedException();
    }

    public override void Kızmak()
    {
        throw new NotImplementedException();
    }

    public override string Sevgi()
    {
       
        return "ÇOIOOOK TEŞEKKRÜLERRRRR EMEYZİİNGGG";
    }
}
public class Bakici
{
    List<ErkekBebek> baktigiBebekler = new List<ErkekBebek>();
    public void CocukAgliyor(ErkekBebek _aglayanBebek)
    {
        if (baktigiBebekler.Contains(_aglayanBebek))
        {
            _aglayanBebek.AglamayiKes();
        }
    }
    public void BebegiDoyur(ErkekBebek _AcBebek)
    {
        _AcBebek.Ye();
    }
}
public class ErkekBebek : Anne
{
    public Bakici MyBakici = new Bakici();
    public void Ye()
    {
        // yemek yeniyor...
    }
    public void AglamayiKes()
    {
        // aglama kesildi.
    }
    public override Color EyeColor { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

    public override void Kızmak()
    {
        throw new NotImplementedException();
    }

    public override string Sevgi()
    {
        return "Ingee";
    }
}
public class Cocuk1_Cocuk1 : Cocuk1
{

}
public class Cocuk1_Cocuk2 : Cocuk1
{
    public int BitCoin;
    public override Color EyeColor { get => Color.LightGray; set => base.EyeColor = value; }

    public override string Sevgi()
    {
        return base.Sevgi();
    }
}
public class Cocuk2 : Anne
{
    public override Color EyeColor { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

    public override void Kızmak()
    {
       
    }  

}

