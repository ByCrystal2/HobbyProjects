﻿
using _10022024_AbstractClassLearning_HobbyProject;
namespace _10022024_AbstractClassLearning_HobbyProject
{
    internal class Program
    {
        static Okul o;
        static void Main(string[] args)
        {
            //Okul okul = new Okul();
            //okul.BakanlikKapama();
        }
    }
    internal abstract class CumhurBaskani
    {       
        public abstract void BakanlikKapama();
       
    }
    internal class MEB : CumhurBaskani
    {
        public override void BakanlikKapama()
        {
            throw new NotImplementedException();
        }

    }
    internal class Okul : MEB
    {

    }
}
// Library projesindeki bir sınıf
internal class InternalClass
{
    // internal erişim belirleyicisi ile bir metot
    internal void InternalMethod()
    {
        Console.WriteLine("Bu metod internal ve sadece aynı derleme içinden erişilebilir.");
    }
}

// Library projesindeki başka bir sınıf
public class PublicClass
{
    // PublicClass, InternalClass'tan türetiliyor
    InternalClass internalInstance = new InternalClass();

    public void CallInternalMethod()
    {
        // PublicClass, InternalClass'taki metodu çağırabilir
        internalInstance.InternalMethod();
    }
}
