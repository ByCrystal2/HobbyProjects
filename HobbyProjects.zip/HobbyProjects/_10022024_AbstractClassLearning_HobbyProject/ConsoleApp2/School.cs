﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public abstract class School
    {
        public int ID;
        public string Name;
        public SchoolType schoolType;
        public List<Employee> Employees = new List<Employee>();
        public School(int _id, string _name, SchoolType _schoolType) 
        {
            ID = _id;
            Name = NameGenerator(_name);
            schoolType = _schoolType;
        }
        public void AddEmployees(List<Employee> _employees)
        {
            Employees.Clear();
            int length = _employees.Count;
            for (int i = 0; i < length; i++)
            {
                Employees.Add(_employees[i]);
            }
        }
        public void AddEmployee(Employee _employee)
        {
            if (!Employees.Contains(_employee))
            {
                Employees.Add(_employee);
            }
            else
            {
                Console.WriteLine("Böyle bir personel zaten okulda kayıtlı.");
            }
        }
        protected string NameGenerator(string _name)
        {
            switch (schoolType)
            {
                case SchoolType.FirstSchool:
                    return _name + " İlk Okul'u";
                case SchoolType.MiddleSchool:
                    return _name + " Orta Okul'u";
                case SchoolType.HighSchool:
                    return _name + " Lise'si";
                default:
                    return "Okul İsimsiz.";
            }
        }
    }
    public class FirstSchool : School
    {
        public FirstSchool(int _id, string _name, SchoolType _schoolType) : base(_id, _name, _schoolType)
        {

        }
    }
    public class MiddleSchool : School
    {
        public MiddleSchool(int _id, string _name, SchoolType _schoolType) : base(_id, _name, _schoolType)
        {
        }
    }
    public class HighSchool : School
    {
        public HighSchool(int _id, string _name, SchoolType _schoolType) : base(_id, _name, _schoolType)
        {
        }
    }
    public enum SchoolType
    {
        FirstSchool,
        MiddleSchool,
        HighSchool
    }
    public enum SchoolEmployeeType
    {
        Teacher,
        Mudur
    }
}

