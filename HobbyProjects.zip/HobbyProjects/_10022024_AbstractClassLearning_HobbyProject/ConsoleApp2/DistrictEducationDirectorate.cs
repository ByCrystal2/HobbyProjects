﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class DistrictEducationDirectorate
    {
        public int ID;
        public string Name;
        public List<School> schoolList = new List<School>();

        public DistrictEducationDirectorate(int _id, string _name)
        {
            ID = _id;
            Name = _name;
        }
        public void AddSchool(School _school)
        {
            schoolList.Add(_school);
        }
    }
}
