﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Teacher : Employee
    {
        public Teacher(int _id, int _schoolId, string _name, decimal _salary, bool _control, SchoolEmployeeType _employeeType) : base(_id, _schoolId, _name, _salary, _control, _employeeType)
        {

        }
    }
}
