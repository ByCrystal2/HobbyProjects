﻿

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DistrictEducationDirectorate DED = new DistrictEducationDirectorate(0,"Osmaniye İlçe Eğitim Müdürlüğü");

            HighSchool highSchool = new HighSchool(1, "Ergen Toplanma Noktası", SchoolType.HighSchool);

            List<Employee> currentSchoolEmployess = new List<Employee>();

            Mudur mudur = new Mudur(0, highSchool.ID, "Fatma Gül Gök", 25000.00m, false, SchoolEmployeeType.Mudur);
            Teacher teacher = new Teacher(1, highSchool.ID, "Ahmet Burak", 20000.00m, false, SchoolEmployeeType.Teacher);

            
            currentSchoolEmployess.Add(mudur);
            currentSchoolEmployess.Add(teacher);

            highSchool.AddEmployees(currentSchoolEmployess);

            DED.AddSchool(highSchool);

            Console.WriteLine($"{DED.Name} adlı ilçe eğitim müdürlüğünün okulları aşağıda listelenmektedir:");

            foreach (var school in DED.schoolList)
            {
                Console.WriteLine($"{school.Name} adlı okulun personelleri şunlardır:");
                foreach (var employee in school.Employees)
                {
                    Console.WriteLine(employee.Name);
                }
            }
        }
    }
}
