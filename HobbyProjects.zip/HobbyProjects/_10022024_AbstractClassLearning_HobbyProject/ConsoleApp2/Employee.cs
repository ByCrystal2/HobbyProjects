﻿using System;

namespace ConsoleApp2
{
    public class Employee
    {
        public int ID;
        public int SchoolID;
        public string Name;
        public decimal Salary; // maas
        public bool Control;
        public SchoolEmployeeType EmployeeType;

        public Employee(int _id, int _schoolId, string _name, decimal _salary, bool _control, SchoolEmployeeType _employeeType)
        {
            ID = _id;
            Name = _name;
            Salary = _salary;
            Control = _control;
            EmployeeType = _employeeType;
        }

    }
}
