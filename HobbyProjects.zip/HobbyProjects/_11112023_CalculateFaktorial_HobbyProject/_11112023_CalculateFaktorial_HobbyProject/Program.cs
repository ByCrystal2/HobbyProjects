﻿namespace _11112023_CalculateFaktorial_HobbyProject
{
    internal class Program
    {

        static void Main(string[] args)        
        {
            
            Console.WriteLine($"Factorial: {CalculateFactorial(GetUserValue("Faktoriyel'ini bulmak istediğiniz sayıyı giriniz: "))}");
        }

        public static int CalculateFactorial(int value)
        {
            if (value <= 1)
                return 1;
            return value * CalculateFactorial(value - 1);
        }

        public static int GetUserValue(string message)
        {
            Console.Write(message);
            return int.Parse(Console.ReadLine());
        }
    }
}