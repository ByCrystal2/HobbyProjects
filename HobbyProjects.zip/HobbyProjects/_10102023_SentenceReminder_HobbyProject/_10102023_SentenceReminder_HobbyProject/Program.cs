﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace _10102023_SentenceReminder_HobbyProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TimerController(GetUserValueOfTime(), GetUserSentenceOfTime());
            Console.ReadKey();
        }

        static string GlobalDurationMessage = "saniye içerisinde konsol temizlenecektir.";
        private static void Wait(int duration, string message)
        {
            for (int i = duration; i >= 0; i--)
            {
                Console.WriteLine(i+" " +message);
                System.Threading.Thread.Sleep(1000);                
            }
        }
        public static string[] GetUserValueOfTime()
        {
            main:
            Console.Write("Lütfen belirlemek istediğiniz zamanı giriniz: "); // 21:00 || 21.00 bu durumda napılacak.
            
            string[] time = Console.ReadLine().Split(':', '.', ',', ' '); // => 12:00 ==> time[0] = 12 | time[1] = 00
            string[] currentTime = new string[2];
            if (time.Length != currentTime.Length)
            {
                currentTime[0] = time[0];
                currentTime[1] = "00";
            }
            else
            {
                currentTime = time;
            }
            if (DateTime.Now.Hour > int.Parse(currentTime[0]) && DateTime.Now.Minute > int.Parse(currentTime[1]))
            {
                Console.WriteLine("Hata1!: Lütfen girdiğiniz alarm saati ve dakikası geçerli olan saatten ve dakikadan büyük olsun.");
                Wait(3, GlobalDurationMessage);
                Console.Clear();
                goto main;
            }
            else if (DateTime.Now.Hour > int.Parse(currentTime[0]))
            {
                Console.WriteLine("Hata2!: Lütfen girdiğiniz alarm saati geçerli olan saatten büyük olsun.");
                Wait(3, GlobalDurationMessage);
                Console.Clear();
                goto main;
            }
            else if (DateTime.Now.Hour == int.Parse(currentTime[0]) && DateTime.Now.Minute > int.Parse(currentTime[1]))
            {
                Console.WriteLine("Hata3!: Lütfen girdiğiniz alarm dakikası geçerli olan dakikadan büyük olsun.");
                Wait(3, GlobalDurationMessage);
                Console.Clear();
                goto main;
            }
            else if (DateTime.Now.Hour == int.Parse(currentTime[0]) && DateTime.Now.Minute == int.Parse(currentTime[1]))
            {
                Console.WriteLine("Hata4!: Lütfen girdiğiniz alarm vakti geçerli vakte eşit olmasın.");
                Wait(3, GlobalDurationMessage);
                Console.Clear();
                goto main;
            }
            else
            {
                return currentTime;
            }
        }

        public static string GetUserSentenceOfTime()
        {
            Console.WriteLine("Lütfen belirtilen zaman dolduğunda verilecek mesajı giriniz: ");
            return Console.ReadLine();
        }

        public static void TimerController(string[] time , string timeSentence)
        {
            int hour = int.Parse(time[0]);            
            int minute = int.Parse(time[1]);
            int minuteControl = 1;

            for (int i = 0; i < int.MaxValue; i++)
            {
                int currentHour = DateTime.Now.Hour;
                int currentMinute = DateTime.Now.Minute;
                if (DateTime.Now.Minute <= 9)
                {
                    currentMinute = int.Parse("0" + DateTime.Now.Minute); // 9 <= 0 + minute (09,08,07,06,...)
                }
                else
                {
                    currentMinute = DateTime.Now.Minute; // 9 > minute (10,11,12,13,...)
                }

                if (hour == currentHour && minute == currentMinute) // Saat ve Dakika Eşitse == True 
                {                    
                    break;
                }
                else
                {
                    if (minuteControl >= 60 || minuteControl == 1)
                    {
                        if ((hour - currentHour) == 0)
                        {
                            Console.WriteLine("Alarm Beklemede... Alarmın çalmasına: " + (minute - currentMinute).ToString() + " Dakika Kaldı");
                        }
                        //else if (currentHour > hour)
                        //{
                        //    Console.WriteLine("Hata!: Lütfen girdiğiniz alarm vakti geçerli olan vakitten büyük olsun.");
                        //}
                        else
                        {
                            Console.WriteLine("Alarm Beklemede... Alarmın çalmasına: " + (hour - currentHour).ToString() + " Saat " + (minute - currentMinute).ToString() + " Dakika Kaldı"); // 12:00 | 13:00 => Alarm Beklemede... Alarmın çalmasına: " + 1 + "Saat " + 00 + "Dakika Kaldı
                        }
                        minuteControl = 1;
                    }
                    else
                    {
                        //Console.WriteLine(minuteControl);
                    }
                    
                }
                System.Threading.Thread.Sleep(1000);
                minuteControl++;
            }
            Console.WriteLine("Alarm: " + timeSentence);
        }


    }
}
