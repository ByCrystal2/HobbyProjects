﻿using System;
using System.Collections.Generic;

namespace _11112023_FourOperations_HobbyProject
{
    internal class Program
    {
        static void Main()
        {
            char[] valueControl = GetUserValue("Lütfen kaç sayıyla işlem yapacağınızı belirtiniz: ").ToCharArray();
            
            string correctUserValue = "";
            foreach (char c in valueControl)
            {                
                if (char.IsDigit(c) || c == ',')
                {
                    
                    correctUserValue += c;
                }                
            } 
            
            float reverseValue = MathF.Round(float.Parse(correctUserValue));
            if (int.TryParse(reverseValue.ToString(),out int numberOfValues) && numberOfValues < 0)
            {
                Console.WriteLine("0 değerle işlem yapılmaz tekrar deneyiniz...");
                WaitForConsoleClearing(3);
                Main();
                return;
            }
            else
            {
                //Console.WriteLine("Lütfen Geçerli Bir Sayı Giriniz!");
                //WaitForConsoleClearing(3);
                //Main();
                //return;
            }

            float[] values = new float[numberOfValues];
            
            for (int i = 0; i < numberOfValues; i++)
            {
                values[i] = float.Parse(GetUserValue($"{i + 1}. sayıyı giriniz: "));
            }

            OperationType operationType = GetOperationType();

            if (operationType != OperationType.None)
            {
                float result = CalculateOperation(values, operationType);
                Console.WriteLine($"Sonuç: {result}");
            }
            else
            {
                Console.WriteLine("Geçersiz işlem türü seçildi.");
            }
        }

        public static float CalculateOperation(float[] values, OperationType opType)
        {
            float result = values[0];

            for (int i = 1; i < values.Length; i++)
            {
                result = Operations[opType](result, values[i]);
            }

            return result;
        }

        public static void WaitForConsoleClearing(int duration)
        {
            for (int i = duration; i >0 ; i--)
            {
                Console.WriteLine("Consolun Temizlenmesine Son " + i + " Saniye...");
                System.Threading.Thread.Sleep(1000);
            }
            Console.Clear();
        }
        public static OperationType GetOperationType()
        {
            Console.WriteLine("Lütfen yapmak istediğiniz işlemi seçiniz:");
            Console.WriteLine("1. Toplama");
            Console.WriteLine("2. Çıkarma");
            Console.WriteLine("3. Çarpma");
            Console.WriteLine("4. Bölme");

            int choice;
            if (int.TryParse(Console.ReadLine(), out choice) && Operations.ContainsKey((OperationType)choice))
            {
                return (OperationType)choice;
            }
            else
            {
                Console.WriteLine("Geçersiz giriş.");
                return OperationType.None;
            }
        }

        public static string GetUserValue(string message)
        {
            Console.WriteLine(message);            
            return Console.ReadLine();
        }

        private static readonly Dictionary<OperationType, Func<float, float, float>> Operations = new Dictionary<OperationType, Func<float, float, float>>
        {
            { OperationType.Addition, (x, y) => x + y },
            { OperationType.Subtraction, (x, y) => x - y },
            { OperationType.Multiply, (x, y) => x * y },
            { OperationType.Division, (x, y) => y != 0 ? x / y : throw new DivideByZeroException("Sıfıra bölme hatası.") }
        };
    }

    public enum OperationType
    {
        None,
        Addition,
        Subtraction,
        Multiply,
        Division,       
    };
}
