﻿using System.Numerics;

namespace test
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            string ad = "Ahmet", soyad = "Burak";

            byte yas = 21;
            string yasGrubu = (yas) switch
            {
                >=65 => "Yaşlı", 
                >= 26 and <= 64 => "Yetkişkin",
                >= 13 and <= 25 => "Genç",
                >= 3 and <= 12 => "Çocuk",
                >= 0 and <= 2 => "Bebek",
            };
            Console.WriteLine(ad + " " + soyad + " adlı kişinin Yaş Grubu: " + yasGrubu);
        }        
    }
}