﻿namespace _08112023_CalculateField_HobbyProjects
{
    internal class Program
    {
        public static int CurrentUserClickedKeyword;
        public static GeoType CurrentUserGeoType;
        public static NPCSate CurrentNPCSate;
        static void Main()
        {
            /* // Alan hesaplama
             * Kare: A2
             * Dikdortgen: A.B
             * Uçgen: (H.T)/2
             * Daire: Pi.R2
            */

            /*
             * 1 => Kare
             * 2 => Dikdortgen
             * 3 => Uçgen
             * 4 => Daire
             * 0 => Cikis
             */
            BaseQueries();
            
            (float geoDeger, string geoSekil) = UserValueControl(GetUserValue());

            if (geoDeger == 0 && geoSekil == "")
            {
                Console.WriteLine("-----------------SİSTEM RESETLENİYOR!-----------------------");
                WaitForConsoleClearing(5);
                Console.Clear();
                Main();
                return;
            }
            else if (geoDeger == 0)
            {
                main1:
                Console.WriteLine("Hata! "+ geoSekil+"'nin alanı 0 olamaz!" + "\nBelirttiğiniz bilgilere göre bir işlem türü bulunmamaktadır.");
                WaitForConsoleClearing(3);
                Console.Clear();
                (float failedGeoDeger, string failedGeoSekil) = UserValueControl(CurrentUserClickedKeyword);
                if (failedGeoDeger == 0)
                {                    
                    goto main1;
                }
                else
                {
                    Console.WriteLine("Belirttiğiniz bilgilere göre " + failedGeoSekil + "'nin Alanı: " + failedGeoDeger);
                    WaitForConsoleClearing(5);
                    Console.Clear();
                    Main();
                }
            }
            else
            {
                Console.WriteLine("Belirttiğiniz bilgilere göre " + geoSekil + "'nin Alanı: " + geoDeger);
                WaitForConsoleClearing(5);
                Console.Clear();
                Main();
            }

            Console.ReadKey();

        }

        public static int GetUserValue() // 0 1 2 3 4
        {
            int value = int.Parse(Console.ReadLine());
            return value;
        }

        public static (float GeoDeger , string GeoSekil) UserValueControl(int _value)
        {
            Console.WriteLine("-Sistem başlatıldı!-");
            if (_value == 0)
            {
                return (0, "");
            }
            else if (_value == 1) 
            {                
                return (KareHesapla(),"Kare");
            }
            else if (_value == 2)
            {
                CurrentUserGeoType = GeoType.Dikdortgen;
                return (DikdortgenHesapla(), "Dikdortgen");
            }
            else if (_value == 3)
            {
                return (UcgenHesapla(), "Ucgen"); ;
            }
            else if (_value == 4)
            {
                return ( DaireHesapla(), "Daire");
            }
            else
            {
                WaitForConsoleClearing(3);
                return (0, "Geçersiz Giriş denemesi");                
            }
            
        }

        public static void GeoController()
        {
            // Debug.Log("Para geldi" + gold);
            float sonuc = (CurrentUserGeoType) switch
            {
                GeoType.Kare => KareHesapla(),
                GeoType.Dikdortgen => DikdortgenHesapla(),
                GeoType.Ucgen => UcgenHesapla(),
                GeoType.Daire => DaireHesapla(),
                GeoType.Null => UcgenHesapla()

            };
        }
        public static void BaseQueries()
        {
            Console.WriteLine("Kare hesap işlemi için 1'e Tıklayınız.");
            Console.WriteLine("Dikdortgen hesap işlemi için 2'ye Tıklayınız.");
            Console.WriteLine("Ucgen hesap işlemi için 3'e Tıklayınız.");
            Console.WriteLine("Daire hesap işlemi için 4'e Tıklayınız.");
            Console.WriteLine("Çıkmak için 0'a Tıklayınız.");
            Console.WriteLine("------------------------------------------------------------------");
        }
        public static void WaitForConsoleClearing(int _duration)
        {
            Console.WriteLine("---------------------------------------------------------------");
            for (int i = _duration; i > 0; i--)
            {
                if (CurrentNPCSate != NPCSate.Walk)
                {
                 Console.WriteLine("Yürüyemedi");

                }
                Console.WriteLine("Consol " + i + " Saniye içerisinde temizlenecektir...");
                System.Threading.Thread.Sleep(1000);
            }
        }
        public static float KareHesapla()
        {
            Console.Write("Lütfen Karenin Kenar Uzunluğunu Giriniz: ");
            float edge = float.Parse(Console.ReadLine());
            Console.WriteLine();
            CurrentUserClickedKeyword = 1;
            float file = edge * edge;
            return file;
        }
        public static float DikdortgenHesapla()
        {
            main:
            Console.Write("Lütfen Dikdortgen'in Uzun Kenarını Giriniz: ");
            float tallEdge = float.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.Write("Lütfen Dikdortgen'in Kısa Kenarını Giriniz: ");
            float shortEdge = float.Parse(Console.ReadLine());
            CurrentUserClickedKeyword = 2;

            if (shortEdge > tallEdge)
            {
                Console.WriteLine("Kısa kenar, uzun kenardan uzun olamaz.");
                WaitForConsoleClearing(3);
                Console.Clear();
                goto main;
            }
            float file = tallEdge * shortEdge;
            return file;
        }
        public static float UcgenHesapla()
        {
            Console.Write("Lütfen Ucgen'in Taban Uzunluğunu Giriniz: ");
            float baseEdge = float.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.Write("Lütfen Ucgen'in Yüksekliğini Giriniz: ");
            float heightEdge = float.Parse(Console.ReadLine());
            CurrentUserClickedKeyword = 3;

            float file = (baseEdge * heightEdge)/2;
            return file;
        }
        public static float DaireHesapla()
        {
            Console.Write("Lütfen Daire'nin Yarı Çapını Giriniz: ");
            float halfDiameter = float.Parse(Console.ReadLine());
            CurrentUserClickedKeyword = 4;
            float file = (float)Math.PI * (halfDiameter * halfDiameter);
            return file;
        }

        
        public void Update()  // Bilgisayarın saniyede ki fps değeri kadar çağrılır. // Benim fpsim 60
        {
            // Benim rotasyonum = mouse.position;
        }
    }

}
public enum GeoType
{
    Null,
    Kare,
    Dikdortgen,
    Ucgen,
    Daire
}

public enum NPCSate
{
    Idle,
    Walk,
    Run,
    Fight,
    Hit,
}