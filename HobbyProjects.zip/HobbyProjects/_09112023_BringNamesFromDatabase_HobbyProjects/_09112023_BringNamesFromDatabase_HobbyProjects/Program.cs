﻿using System.Net.Http.Headers;

namespace _09112023_BringNamesFromDatabase_HobbyProjects
{
    internal class Program
    {
        // Kullanıcıdan 3 karakter istiyeceğiz. Bu isteyeceğimiz 3 karaktere göre, isimler listesinden arama yapıp, bu karakterlere uyan ve en çok bunu bulunduran ismi çekeceğiz.//

        public static HumanManager _humanManager = new HumanManager();
        public static Exception _ex;
        static void Main()
        {
            _humanManager.AddNames();
            BaseOptions();
            List<HumanData> currentHumans = _humanManager.GetDesiredHumans(GetUserValues(3));
            if (_ex != null)
            {
                Console.WriteLine(_ex.Message);
                _ex = null;
                AppEnding();
                return;
            }
            
            if (currentHumans.Count == 0)
            {
                Console.WriteLine("Vermiş olduğunuz bilgilere göre kullanıcı bulunamadı.");
                AppEnding();
                return;
            }
            
            foreach (var human in currentHumans)
            {
                Console.WriteLine("-------------------------------"+ human.Name + " " + human.Surname + "-------------------------------");
                Console.WriteLine();
                Console.WriteLine("Fullname: " + human.Name + " " + human.Surname);
                Console.WriteLine("Age: " + human.Age);
                Console.WriteLine("DateOfBirth: " + human.DateOfBirth.ToShortTimeString());
                Console.WriteLine("Description: " + human.Description);
                Console.WriteLine(); Console.WriteLine();
            }
            AppEnding();

        }

        public static void AppEnding()
        {
            main:
            Console.WriteLine("Uygulamayı resetlemek için lütfen 0'ı tuşlayınız: ");
            int deger = int.Parse(Console.ReadLine());
            if (deger == 0)
            {
                WaitForConsoleClearing(3);
                Console.Clear();
                Main();
            }
            else Console.Clear(); goto main;
        }

        public static void WaitForConsoleClearing(int _duration)
        {
            for (int i = _duration; i > 0; i--)
            {
                Console.WriteLine("Consolun temizlenmesine " + i + " saniye kaldı...");
                System.Threading.Thread.Sleep(1000);
            }
        }
        public static void BaseOptions()
        {
            Console.WriteLine("-----------------------------KİMLİK BULMA SİSTEMİNE HOŞ GELDİNİZ! -----------------------------");
        }
        public static char[] GetUserValues(int _charNumber)
        {
            Console.WriteLine("Lütfen "+ _charNumber + " karakter giriniz: ");
            char[] CurrentChars = Console.ReadLine().ToCharArray();
            if (UserValuesControl(CurrentChars,_charNumber)) return CurrentChars;            
            else 
            { 
                _ex = new Exception("Lütfen İstenen Değer Kadar Karakter Giriniz. (Örn:"+ new string("abcçdefgğhıijklmnoöprsştuüvyz").Substring(0,_charNumber) + ")");
                return new char[] {'0'};
            }
        }

        public static bool UserValuesControl(char[] _chars, int _number)
        {
            if (_number == _chars.Length) return true;
            else return false;
        }
    }
    public class HumanData
    {
        public int ID { get; private set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Age { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Description { get; set; }
        public HumanData(int _id, string _name, string _surname, DateTime _dateOfBirth, string _description = "Bilgi bulunmamakta.")
        {
            this.ID = _id;
            this.Name = _name;
            this.Surname = _surname;
            this.Age = DateTime.Now.Year - _dateOfBirth.Year;
            this.DateOfBirth = _dateOfBirth;
            this.Description = _description;
        }
    }
    public class HumanManager
    {
        public List<HumanData> Humans = new List<HumanData>();
        
        public void AddNames()
        {
            HumanData h1 = new HumanData(1, "Fatma Gül", "Gök", new DateTime(2002, 11, 19), "Queen Of The World.");
            HumanData h2 = new HumanData(2, "Ahmet", "Burak", new DateTime(2002, 04, 18), "Someone Who Is In Love With The Queen");
            HumanData h3 = new HumanData(3, "Nicola", "Tesla", new DateTime(1959, 11, 19), "Father Of Physics");
            HumanData h4 = new HumanData(4, "John", "Smith", new DateTime(1985, 3, 15), "Engineer");
            HumanData h5 = new HumanData(5, "Emily", "Johnson", new DateTime(1992, 8, 27), "Teacher");
            HumanData h6 = new HumanData(6, "David", "Williams", new DateTime(1979, 12, 3), "Lawyer");
            HumanData h7 = new HumanData(7, "Sarah", "Brown", new DateTime(2000, 7, 10), "Journalist");
            HumanData h8 = new HumanData(8, "Michael", "Davis", new DateTime(1988, 5, 21), "Doctor");
            HumanData h9 = new HumanData(9, "Jessica", "Taylor", new DateTime(1996, 9, 9), "Artist");
            HumanData h10 = new HumanData(10, "Robert", "Jones", new DateTime(1974, 2, 14), "Entrepreneur");
            HumanData h11 = new HumanData(11, "Jennifer", "Clark", new DateTime(1982, 6, 7), "Scientist");
            HumanData h12 = new HumanData(12, "Daniel", "Lewis", new DateTime(1991, 10, 25), "Musician");
            HumanData h13 = new HumanData(13, "Emma", "White", new DateTime(1999, 4, 12), "Writer");
            HumanData h14 = new HumanData(14, "James", "Thomas", new DateTime(1978, 1, 30), "Chef");
            HumanData h15 = new HumanData(15, "Olivia", "Harris", new DateTime(1987, 11, 8), "Athlete");
            HumanData h16 = new HumanData(16, "William", "Wilson", new DateTime(1994, 12, 18), "Politician");
            HumanData h17 = new HumanData(17, "Sophia", "Anderson", new DateTime(2001, 6, 4), "Psychologist");
            HumanData h18 = new HumanData(18, "Alexander", "Martinez", new DateTime(1990, 9, 3), "Architect");
            HumanData h19 = new HumanData(19, "Mia", "Thompson", new DateTime(1983, 7, 28), "Journalist");
            HumanData h20 = new HumanData(20, "Ethan", "Lee", new DateTime(1997, 3, 9), "Software Developer");

            Humans.Add(h1);
            Humans.Add(h2);
            Humans.Add(h3);
            Humans.Add(h4);
            Humans.Add(h5);
            Humans.Add(h6);
            Humans.Add(h7);
            Humans.Add(h8);
            Humans.Add(h9);
            Humans.Add(h10);
            Humans.Add(h11);
            Humans.Add(h12);
            Humans.Add(h13);
            Humans.Add(h14);
            Humans.Add(h15);
            Humans.Add(h16);
            Humans.Add(h17);
            Humans.Add(h18);
            Humans.Add(h19);
            Humans.Add(h20);
        }

        public HumanData GetHuman(int _id)
        {            
            return Humans.Where(x => x.ID == _id).FirstOrDefault();
        }
        public List<HumanData> GetDesiredHumans(char[] _characters)
        {
            
            List<string> AllHumanNamesAndSurnames =Humans.Select(x=> x.Name + " " + x.Surname).ToList();
            List<HumanData> validHumans = new List<HumanData>();                      
            foreach (var fullName in AllHumanNamesAndSurnames)
            {
                int point = 0;
                string copyFullName = fullName;
                foreach (var character in _characters)
                {                    
                    if (copyFullName.Contains(character))
                    {
                        copyFullName = copyFullName.Replace(character,' ');
                        point++;
                    }
                }
                if (point == _characters.Length)
                {
                    validHumans.Add(Humans.Where(x=> (x.Name + " " + x.Surname) == fullName).FirstOrDefault());
                }            }
            return validHumans;
        }
    }
}