﻿namespace _11112023_RulesOfFibonacci_HobbyProjects
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> fibonacciNumbers = FibonacciControl(GetUserValue("Lütfen Hangi Sayıya Kadar Fibonacci değeri göstermek istediğinizi belirten bir değer giriniz: "));
            foreach (var number in fibonacciNumbers)
            {
                Console.WriteLine(number);
            }
        }

        public static int GetUserValue(string _message)
        {
            Console.Write(_message);
            return int.Parse(Console.ReadLine());
        }

        public static List<int> FibonacciControl(int _userValue)
        {
            List<int> fibonacciNumbers = new List<int>();
            int currentFibonacci = 1, lastFibonacci = 0;
            fibonacciNumbers.Add(lastFibonacci);
            fibonacciNumbers.Add(currentFibonacci);

            for (int i = 2; i < _userValue; i++)
            {
                int newFibonacci = currentFibonacci + lastFibonacci;
                lastFibonacci = currentFibonacci;
                currentFibonacci = newFibonacci;
                fibonacciNumbers.Add(currentFibonacci);
            }

            return fibonacciNumbers;
        }
    }
}
