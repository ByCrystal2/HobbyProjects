﻿using _19122023_OOPLearning1_TobetoMeslekiEgitim;

namespace _19122023_OOPLearning1_TobetoMeslekiEgitim
{
        internal class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("WELCOME TO MY GAME!\n");

                // Karakterlerin oluşturulması
                Warrior warrior1 = new Warrior(100, 150, 20.0f, 5.0f, 1.5f);
                Archer archer1 = new Archer(80, 120, 25.0f, 20.0f, 2.0f);
                Wizard wizard1 = new Wizard(120, 100, 18.0f, 10.0f, 1.8f);
                Bulwark bulwark1 = new Bulwark(150, 200, 15.0f, 3.0f, 1.2f);

                // Karakterlere yeteneklerin eklenmesi
                warrior1.Abilities.Add(new FireballAbility()); // Örnek olarak aynı yeteneği ekledim
                warrior1.Abilities.Add(new StealthAbility()); // Örnek olarak aynı yeteneği ekledim
                warrior1.Abilities.Add(new FireballAbility()); // Örnek olarak aynı yeteneği ekledim

                archer1.Abilities.Add(new StealthAbility()); // Örnek olarak aynı yeteneği ekledim
                archer1.Abilities.Add(new FireballAbility()); // Örnek olarak aynı yeteneği ekledim
                archer1.Abilities.Add(new StealthAbility()); // Örnek olarak aynı yeteneği ekledim

                wizard1.Abilities.Add(new FireballAbility());
                wizard1.Abilities.Add(new StealthAbility()); // Örnek olarak aynı yeteneği ekledim
                wizard1.Abilities.Add(new FireballAbility()); // Örnek olarak aynı yeteneği ekledim

                bulwark1.Abilities.Add(new StealthAbility()); // Örnek olarak aynı yeteneği ekledim
                bulwark1.Abilities.Add(new FireballAbility()); // Örnek olarak aynı yeteneği ekledim
                bulwark1.Abilities.Add(new StealthAbility()); // Örnek olarak aynı yeteneği ekledim

                // Karakterlere eşyaların eklenmesi
                warrior1.Inventory.AddItem(new Item("Sword", 10, 15, ItemType.Weapon));
                warrior1.Inventory.AddItem(new Item("Axe", 15, 20, ItemType.Weapon));
                warrior1.Inventory.AddItem(new Item("Shield", 20, 25, ItemType.Armor));
                warrior1.Inventory.SetUsedWeaponItem(new Item("Sword", 10, 15, ItemType.Weapon)); // Örnek olarak aynı itemi ekledim

                archer1.Inventory.AddItem(new Item("Bow", 5, 20, ItemType.Weapon));
                archer1.Inventory.AddItem(new Item("Dagger", 8, 25, ItemType.Weapon));
                archer1.Inventory.AddItem(new Item("Arrow", 3, 15, ItemType.Ammo));
                archer1.Inventory.SetUsedWeaponItem(new Item("Bow", 5, 20, ItemType.Weapon)); // Örnek olarak aynı itemi ekledim

                wizard1.Inventory.AddItem(new Item("Magic Gun", 9, 16, ItemType.Weapon));
                wizard1.Inventory.SetUsedWeaponItem(new Item("Magic Gun", 9, 16, ItemType.Weapon)); // Örnek olarak aynı itemi ekledim

                bulwark1.Inventory.AddItem(new Item("Axe", 20, 25, ItemType.Weapon));
                bulwark1.Inventory.AddItem(new Item("Armor", 25, 30, ItemType.Armor));
                bulwark1.Inventory.AddItem(new Item("Helmet", 18, 22, ItemType.Armor));
                bulwark1.Inventory.AddItem(new Item("Gauntlet", 20, 25, ItemType.Armor));
                bulwark1.Inventory.SetUsedWeaponItem(new Item("Axe", 20, 25, ItemType.Weapon)); // Örnek olarak aynı itemi ekledim
                // Takımların oluşturulması
                Team redTeam = new Team(TeamColor.Red);
                Team blueTeam = new Team(TeamColor.Blue);

                // Takımlara karakterlerin eklenmesi
                redTeam.AddMember(warrior1);
                redTeam.AddMember(wizard1);
                blueTeam.AddMember(archer1);
                blueTeam.AddMember(bulwark1);

                // Takımların listelenmesi
                Console.WriteLine("RED TEAM:");
                redTeam.ListMembers();

                Console.WriteLine("\nBLUE TEAM:");
                blueTeam.ListMembers();

                Console.ReadKey();
            }
        }
    public abstract class PlayerBaseStats
    {

        protected int Health;
        protected int MaxHealth;
        protected float AttackPower;
        protected float AttackRange;
        protected float AttackSpeed;
        public PlayerBaseStats(int _health, int _maxHealth, float _attackPower, float _attackRange, float _attackSpeed)
        {
            Health = _health;
            MaxHealth = _maxHealth;
            AttackPower = _attackPower;
            AttackRange = _attackRange;
            AttackSpeed = _attackSpeed;
        }
        public void SetHealth(int _value) { Health = _value; }
        public void SetMaxHealth(int _value) { MaxHealth = _value; }
        public void SetAttackPower(float _value) { AttackPower = _value; }
        public void SetAttackRange(float _value) { AttackRange = _value; }
        public void SetAttackSpeed(float _value) { AttackSpeed = _value; }

        public int GetHealth() { return Health; }
        public int GetMaxHealth() { return MaxHealth; }
        public float GetAttackPower() { return AttackPower; }
        public float GetAttackRange() { return AttackRange; }
        public float GetAttackSpeed() { return AttackSpeed; }

        public virtual List<SpecialAbility> GetAbilities()
        {
            return new List<SpecialAbility>(); // Varsayılan olarak boş bir liste döndür
        }
        public virtual Inventory GetInventory()
        {
            return new Inventory(); // Varsayılan olarak boş bir liste döndür
        }

    }

    public abstract class SpecialAbility
    {
        public virtual string? AbilityName { get; }
        // Cooldown Süresi
        public virtual TimeSpan CooldownDuration { get; }

        // Enerji/Kaynak İhtiyacı
        public virtual int EnergyCost { get; }

        // Menzil veya Etki Alanı
        public virtual float Range { get; }

        // Hasar veya Etki Türü
        public virtual EffectType EffectType { get; }

        // Etki Süresi veya Etki Miktarı
        public virtual TimeSpan EffectDuration { get; }
        public abstract void Execute();
    }
    public interface IAttackable
    {
        void BasicAttack();
        void SpecialAttack();
    }
    public interface IDefendable
    {
        void Block();
        void Dodge();
    }
    public class Warrior : PlayerBaseStats, IAttackable, IDefendable
    {
        public List<SpecialAbility> Abilities { get; private set; }
        public Inventory Inventory { get; private set; }

        public Warrior(int health, int maxHealth, float attackPower, float attackRange, float attackSpeed)
            : base(health, maxHealth, attackPower, attackRange, attackSpeed)
        {
            // Warrior'a özgü başka özellikler veya metotlar burada eklenebilir
            Abilities = new List<SpecialAbility>(); // Abilities özelliğini başlangıç değeri ile başlat
            Inventory = new Inventory();
        }

        public void BasicAttack()
        {
            throw new NotImplementedException();
        }

        public void Block()
        {
            throw new NotImplementedException();
        }

        public void Dodge()
        {
            throw new NotImplementedException();
        }

        public void SpecialAttack()
        {
            throw new NotImplementedException();
        }
        public override List<SpecialAbility> GetAbilities()
        {
            return Abilities;
        }
        public override Inventory GetInventory()
        {
            return Inventory;
        }
    }
    public class Archer : PlayerBaseStats, IAttackable, IDefendable
    {
        public List<SpecialAbility> Abilities { get; private set; }
        public Inventory Inventory { get; private set; }

        public Archer(int health, int maxHealth, float attackPower, float attackRange, float attackSpeed)
            : base(health, maxHealth, attackPower, attackRange, attackSpeed)
        {
            // Warrior'a özgü başka özellikler veya metotlar burada eklenebilir
            Abilities = new List<SpecialAbility>(); // Abilities özelliğini başlangıç değeri ile başlat
            Inventory = new Inventory();
        }

        public void BasicAttack()
        {
            throw new NotImplementedException();
        }

        public void Block()
        {
            throw new NotImplementedException();
        }

        public void Dodge()
        {
            throw new NotImplementedException();
        }

        public void SpecialAttack()
        {
            throw new NotImplementedException();
        }
        public override List<SpecialAbility> GetAbilities()
        {
            return Abilities;
        }
        public override Inventory GetInventory()
        {
            return Inventory;
        }
    }
    public class Wizard : PlayerBaseStats, IAttackable, IDefendable
    {
        public List<SpecialAbility> Abilities { get; private set; }
        public Inventory Inventory { get; private set; }

        public Wizard(int health, int maxHealth, float attackPower, float attackRange, float attackSpeed)
            : base(health, maxHealth, attackPower, attackRange, attackSpeed)
        {
            // Warrior'a özgü başka özellikler veya metotlar burada eklenebilir
            Abilities = new List<SpecialAbility>(); // Abilities özelliğini başlangıç değeri ile başlat
            Inventory = new Inventory();
        }

        public void BasicAttack()
        {
            throw new NotImplementedException();
        }

        public void Block()
        {
            throw new NotImplementedException();
        }

        public void Dodge()
        {
            throw new NotImplementedException();
        }

        public void SpecialAttack()
        {
            throw new NotImplementedException();
        }
        public override List<SpecialAbility> GetAbilities()
        {
            return Abilities;
        }
        public override Inventory GetInventory()
        {
            return Inventory;
        }
    }
    public class Bulwark : PlayerBaseStats, IAttackable, IDefendable
    {
        public List<SpecialAbility> Abilities { get; private set; }
        public Inventory Inventory { get; private set; }

        public Bulwark(int health, int maxHealth, float attackPower, float attackRange, float attackSpeed)
            : base(health, maxHealth, attackPower, attackRange, attackSpeed)
        {
            // Warrior'a özgü başka özellikler veya metotlar burada eklenebilir
            Abilities = new List<SpecialAbility>(); // Abilities özelliğini başlangıç değeri ile başlat
            Inventory = new Inventory();
        }

        public void BasicAttack()
        {
            throw new NotImplementedException();
        }

        public void Block()
        {
            throw new NotImplementedException();
        }

        public void Dodge()
        {
            throw new NotImplementedException();
        }

        public void SpecialAttack()
        {
            throw new NotImplementedException();
        }
        public override List<SpecialAbility> GetAbilities()
        {
            return Abilities;
        }
        public override Inventory GetInventory()
        {
            return Inventory;
        }
    }
    public class Ranger : Archer
    {
        public Ranger(int health, int maxHealth, float attackPower, float attackRange, float attackSpeed)
                : base(health, maxHealth, attackPower, attackRange, attackSpeed)
        {
            // Ranger'a özgü başka özellikler veya metotlar burada eklenebilir
        }
    }

    public class Sorcerer : Wizard
    {
        public Sorcerer(int health, int maxHealth, float attackPower, float attackRange, float attackSpeed)
                : base(health, maxHealth, attackPower, attackRange, attackSpeed)
        {
            // Ranger'a özgü başka özellikler veya metotlar burada eklenebilir
        }
    }
    //SKILLS
    public class FireballAbility : SpecialAbility
    {
        public override void Execute()
        {
            Console.WriteLine("Fireball casted!");
            // Fireball yeteneğinin özelliklerini ve davranışlarını buraya ekleyebilirsiniz
        }
        public override string? AbilityName => "Fireball";
        public override TimeSpan CooldownDuration => TimeSpan.FromSeconds(10);

        public override int EnergyCost => 20;

        public override float Range => 8.0f;

        public override EffectType EffectType => EffectType.Damage;

        public override TimeSpan EffectDuration => TimeSpan.FromSeconds(5);
    }

    public class StealthAbility : SpecialAbility
    {
        public override void Execute()
        {
            Console.WriteLine("Stealth activated!");
            // Gizlenme yeteneğinin özelliklerini ve davranışlarını buraya ekleyebiliriz
        }
        public override string? AbilityName => "Stealth";
        public override TimeSpan CooldownDuration => TimeSpan.FromSeconds(15);
        public override EffectType EffectType => EffectType.Debuff;
        public override int EnergyCost => 30;
    }
    public enum EffectType
    {
        Damage,
        Healing,
        Buff,
        Debuff,
        // Diğer etki türleri buraya eklenebilir
    }
}
