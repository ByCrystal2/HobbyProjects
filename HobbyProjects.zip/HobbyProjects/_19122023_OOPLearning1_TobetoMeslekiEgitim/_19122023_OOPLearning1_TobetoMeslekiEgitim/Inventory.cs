﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19122023_OOPLearning1_TobetoMeslekiEgitim
{
    public class Inventory
    {
        private List<Item> items;
        private Item? CurrentItem;
        public Inventory()
        {
            items = new List<Item>();
        }

        public void AddItem(Item item)
        {
            items.Add(item);
        }
        
        public Item GetUsedItem()
        {
            if (CurrentItem != null)            
                return CurrentItem;
            else return new Item();
        }
        public void SetUsedWeaponItem(Item item)
        {
            if (item.ItemType == ItemType.Weapon)            
                CurrentItem = item;
            else 
                CurrentItem = null;
        }
        public void RemoveItem(Item item)
        {
            items.Remove(item);
        }

        public List<Item> GetItems()
        {
            List<Item> copyItems = new List<Item>();
            for (int i = 0; i < items.Count; i++)
            {
                copyItems.Add(items[i]);
            }
            return copyItems;
        }

        // Diğer envanter işlemleri burada eklenebilir
    }

}
public class Item
{
    public string? Name { get; set; }
    public int HealthBonus { get; set; }
    public int AttackBonus { get; set; }
    public ItemType ItemType { get; set; }
    // Eşyanın sağlık veya saldırı bonusları gibi özellikleri buraya eklenebilir
    public Item(string? name, int healthBonus, int attackBonus, ItemType itemType)
    {
        Name = name;
        HealthBonus = healthBonus;
        AttackBonus = attackBonus;
        ItemType = itemType;
    }
    public Item() { }
}
public enum ItemType
{
    None,
    Weapon,
    Armor,
    Helmemt,
    Gauntlet,
    Ammo,
    Dagger
}
