﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19122023_OOPLearning1_TobetoMeslekiEgitim
{
    public sealed class Team
    {
        private List<PlayerBaseStats> members;
        public TeamColor Color { get; private set; }

        public Team(TeamColor color)
        {
            Color = color;
            members = new List<PlayerBaseStats>();
        }

        public Team()
        {
            members = new List<PlayerBaseStats>();
        }

        public void AddMember(PlayerBaseStats member)
        {
            members.Add(member);
        }

        public void RemoveMember(PlayerBaseStats member)
        {
            members.Remove(member);
        }
        
        public void ListMembers()
        {
            Console.WriteLine("---------------------------------------");
            Console.WriteLine("Team Members:");
            foreach (var member in members)
            {
                Console.WriteLine($"- {member.GetType().Name}");
                Console.WriteLine("-------Skills-------");
                member.GetAbilities().ForEach(x => Console.WriteLine("Skill => " + x.AbilityName));
                Console.WriteLine("Weapon => " + member.GetInventory().GetUsedItem().Name + "\n");

            }
        }

        // Diğer takım operasyonları ve davranışları buraya eklenebilir
    }
    public enum TeamColor
    {
        Red,
        Blue
    }
}
