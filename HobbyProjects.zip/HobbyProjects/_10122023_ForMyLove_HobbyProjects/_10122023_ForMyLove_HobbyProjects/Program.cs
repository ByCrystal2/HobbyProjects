﻿namespace _10122023_ForMyLove_HobbyProjects
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}
