﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08022024_LibraryApplication_HobbyProject
{
    public class BookManager
    {
        public List<Book> books = new List<Book>();

        public void InitalizationBooks()
        {
            Book b1 = new Book(0, "Fatma Gül'e Olan Aşkım", "Ahmet Burak", new DateTime(2023, 7, 23),10000);
            Book b2 = new Book(1, "Sonsuzluk Kavşağı", "Amin Maalouf", new DateTime(1996, 1, 1), 20);
            Book b3 = new Book(2, "1984", "George Orwell", new DateTime(1949, 6, 8), 30);
            Book b4 = new Book(3, "Harry Potter and the Philosopher's Stone", "J.K. Rowling", new DateTime(1997, 6, 26), 40);
            Book b5 = new Book(4, "The Great Gatsby", "F. Scott Fitzgerald", new DateTime(1925, 4, 10), 50);
            Book b6 = new Book(5, "To Kill a Mockingbird", "Harper Lee", new DateTime(1960, 7, 11), 60);
            Book b7 = new Book(6, "Pride and Prejudice", "Jane Austen", new DateTime(1813, 1, 28), 70);
            Book b8 = new Book(7, "The Catcher in the Rye", "J.D. Salinger", new DateTime(1951, 7, 16), 80);
            Book b9 = new Book(8, "The Lord of the Rings", "J.R.R. Tolkien", new DateTime(1954, 7, 29), 90);
            Book b10 = new Book(9, "The Hobbit", "J.R.R. Tolkien", new DateTime(1937, 9, 21), 100);

            books.Add(b1);
            books.Add(b2);
            books.Add(b3);
            books.Add(b4);
            books.Add(b5);
            books.Add(b6);
            books.Add(b7);
            books.Add(b8);
            books.Add(b9);
            books.Add(b10);
        }
        public void AddBook(Book book)
        {
            books.Add(book);
        }
        public bool isHasBook(string _bookTitle, string _bookAuthor)
        {
            return books.Any(x=> x.Title == _bookTitle && x.Author == _bookAuthor);
        }
        public Book GetBook(string _bookTitle, string _bookAuthor)
        {
            return books.Where(x=> x.Title == _bookTitle && x.Author == _bookAuthor).SingleOrDefault();
        }
    }
}
