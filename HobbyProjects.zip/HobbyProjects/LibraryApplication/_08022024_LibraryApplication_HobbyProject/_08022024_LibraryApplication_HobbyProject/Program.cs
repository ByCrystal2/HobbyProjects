﻿namespace _08022024_LibraryApplication_HobbyProject
{
    internal class Program
    {
        /* Kütüphane uygulaması yapılacak .
         * Book sınıfı açılacak.
         * Bir kitap listesi yönetilecek.
         * Book (Title, Auhor, PublicationYear)
         * List<Book>
         * Kullanıcı sınıfı açılacak.
         * Kullanıcı kitap ekleyebilecek ve mevcut kitapları listeleyebilecek.
         * Kullanıcı bir kitabın detaylarını görüntülebilmelidir.
         */
        static void Main(string[] args)
        {
            GoMenu();
        }
        public static void GoMenu()
        {
            LibraryManager.BookManager = new BookManager();
            LibraryManager.BookManager.InitalizationBooks();
            BaseInformations();
        }
        private static void BaseInformations()
        {
            Console.WriteLine("Kütüphanemize hoş geldiniz...");
            Console.WriteLine("Size nasıl yardımcı olabiliriz?");
            Console.WriteLine("Kütüphaneye kitap eklemek için kayıt olmalısınız.");
            Console.WriteLine("Kayıt olmak için 'E' \nBu işlemi atlamak için 'H'");
            string UserKey1 = Console.ReadLine().ToUpper();
            if (UserKey1 == "E")
            {
                UserSign();
            }
            else if (UserKey1 == "H")
            {
                Console.WriteLine("Kitap eklemek için giriş yapmalısınız.");
            main:
                Console.WriteLine("Giriş için 'E' \nBu işlemi atlamak için 'H'");
                string UserKey2 = Console.ReadLine().ToUpper();
                if (UserKey2 == "E")
                {
                    LibraryManager.UserLoginLibrary();
                    Console.WriteLine("Eklemek istediğiniz kitabın bilgilerini veriniz.");
                    Console.Write("Kitap Başlığı: ");
                    string bookInfoTitle = Console.ReadLine();
                    Console.Write("Kitap Yazarı: ");
                    string bookInfoAuthor = Console.ReadLine();
                    Console.WriteLine("Kitap Yayımlanma Tarihi (Gün/Ay/Yıl): ");
                    Console.Write("Gün: ");
                    int bookInfoDay = int.Parse(Console.ReadLine());
                    Console.Write("Ay: ");
                    int bookInfoMonth = int.Parse(Console.ReadLine());
                    Console.Write("Yıl: ");
                    int bookInfoYear = int.Parse(Console.ReadLine());
                    Console.Write("Kitap Ücreti: ");
                    float bookInfoPrice = float.Parse(Console.ReadLine());
                    Book _newBook = new Book(LibraryManager.BookManager.books.Last().ID +1,bookInfoTitle, bookInfoAuthor, new DateTime(bookInfoYear,bookInfoMonth,bookInfoDay),bookInfoPrice);
                    LibraryManager.BookManager.AddBook(_newBook);
                    Console.WriteLine("Kitap başarıyla sisteme eklendi! Teşekkürler..");
                    Console.WriteLine("Menuye döndürülüyorsunuz...");
                    SystemWaiting(1);
                    ConsoleClearingWaiting(3);
                    GoMenu();
                }
                else if (UserKey2 == "H")
                {
                    Console.WriteLine("Kütüphanemizde ki kitapları görmek ister misiniz?");
                    Console.WriteLine("Kitapları listelemek için 'E' \nBu işlemi atlamak için 'H'");
                    string UserKey3 = Console.ReadLine().ToUpper();
                    if (UserKey3 == "E")
                    {
                        List<Book> _libraryBooks = LibraryManager.BookManager.books;
                        foreach (var book in _libraryBooks)
                        {
                            Console.WriteLine($"Yazar:{book.Author} Başlık:{book.Title} Çıkış Tarihi:({book.PublicationYear.ToShortDateString()}) Fiyat:{book.Price}TL");
                        }
                        Console.WriteLine("Kitap almak ister misiniz?");
                        Console.WriteLine("Kitap Almak için 'E' \nBu işlemi atlamak için 'H'");
                        string UserKey4 = Console.ReadLine().ToUpper();
                        if (UserKey4 == "E")
                        {
                            Console.WriteLine("Öncelikle giriş bilgilerinizi doğrulamalısınız...");
                            SystemWaiting(1);
                            LibraryManager.UserLoginLibrary();
                            SystemWaiting(2);
                            ConsoleClearingWaiting(3);
                            Console.WriteLine("Lütfen almak istediğiniz kitabın bilgilerini giriniz.");
                            Console.Write("Lütfen Kitap Başlığını Giriniz: ");
                            string BookTitle = Console.ReadLine();
                            Console.Write("Lütfen Kitap Yazarının Adını Giriniz: ");
                            string BookAuthor = Console.ReadLine();
                            if (LibraryManager.BookManager.isHasBook(BookTitle,BookAuthor))
                            {
                                Book currentBook = LibraryManager.BookManager.GetBook(BookTitle,BookAuthor);
                                Console.WriteLine("Kitap sistemde bulundu! ");
                                Console.WriteLine($"Yazar:{currentBook.Author} Başlık:{currentBook.Title} Çıkış Tarihi:({currentBook.PublicationYear.ToShortDateString()}) Fiyat:{currentBook.Price}TL");
                                SystemWaiting(2);
                                Console.Write("Lütfen para miktarınızı giriniz: ");
                                int UserPrice = int.Parse(Console.ReadLine());
                                if (UserPrice >= currentBook.Price)
                                {
                                    User currentUser = LibraryManager.CurrentUser;
                                    currentUser.AddMyLibraryBook(currentBook);
                                    Console.WriteLine($"Hayırlı olsun {currentUser.Name}!\n{currentBook.Title} Başlıklı kitabı başarıyla satın aldınız!");
                                    SystemWaiting(1);
                                    ConsoleClearingWaiting(3);
                                    GoMenu();
                                }
                            }
                            
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Lütfen istenilen değerlerden birini giriniz...");
                    Program.ConsoleClearingWaiting(2);
                    goto main;
                }
            }
        }
        public static void UserSign()
        {
            ConsoleClearingWaiting(3);
            Console.WriteLine("Kayıt için lütfen aşağıda istenilen bilgileri giriniz:");
            Console.WriteLine("Ad: ");
            string _userName = Console.ReadLine();
            Console.WriteLine("Email: ");
            string _userEmail = Console.ReadLine();
            Console.WriteLine("Password: ");
            string _userPassword = Console.ReadLine();
            int _userID;
            if (LibraryManager.SignedUsers.Count <= 0)
            {
                _userID = 0;
            }
            else
            {
                _userID = LibraryManager.SignedUsers.Last().ID + 1;
            }
            User _newUser = new User(_userID, _userName,_userEmail,_userPassword);
            LibraryManager.UserSignLibrary(_newUser);
            GoMenu();
        }
        public static void SystemWaiting(int _time)
        {
            Thread.Sleep(_time*1000);
        }
        public static void ConsoleClearingWaiting(int _time)
        {
            for (int i = _time; i > 0; i--)
            {
                Console.WriteLine("Konsolun temizlenmesine son " + i + " saniye...");
                SystemWaiting(1);
            }
            Console.Clear();
        }
    }
}
