﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08022024_LibraryApplication_HobbyProject
{
    public class Book
    {
        public int ID;
        public string Title;
        public string Author;
        public DateTime PublicationYear;
        public float Price;

        public Book(int _id, string _title, string _author, DateTime _publicationYear, float price)
        {
            ID = _id;
            Title = _title;
            Author = _author;
            PublicationYear = _publicationYear;
            Price = price;
        }
    }
}
