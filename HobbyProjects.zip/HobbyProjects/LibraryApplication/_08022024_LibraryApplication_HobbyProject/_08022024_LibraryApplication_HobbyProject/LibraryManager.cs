﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08022024_LibraryApplication_HobbyProject
{
    public static class LibraryManager
    {
        public static List<User> SignedUsers = new List<User>();
        public static BookManager BookManager;
        public static User CurrentUser;
        public static void UserSignLibrary(User _newUser)
        {
            Program.ConsoleClearingWaiting(3);
            if (!SignedUsers.Contains(_newUser))
            {
                SignedUsers.Add(_newUser);
                Console.WriteLine($"Tebrikler {_newUser.Name}! Başarıyla kayıt oldunuz...");
                Program.SystemWaiting(1);
                Console.WriteLine($"Giriş yapmak ister misiniz?");
                main:
                UserLoginQuestion();
                string UserKey = Console.ReadLine().ToUpper();
                if (UserKey == "E")
                {
                    UserLoginLibrary();
                }
                else if (UserKey == "H")
                {
                    Program.GoMenu();
                }
                else
                {
                    Console.WriteLine("Lütfen istenilen değerlerden birini giriniz...");
                    Program.ConsoleClearingWaiting(2);
                    goto main;
                }
            }
            else
            {
                Console.WriteLine("Sistemde zaten kayıtlısınız, Giriş yapmak ister misiniz?");
                main1:
                UserLoginQuestion();
                string UserKey = Console.ReadLine().ToUpper();
                if (UserKey == "E")
                {
                    UserLoginLibrary();
                }
                else if (UserKey == "H") 
                {
                    Program.GoMenu();
                }
                else
                {
                    Console.WriteLine("Lütfen istenilen değerlerden birini giriniz...");
                    Program.ConsoleClearingWaiting(2);
                    goto main1;
                }

            }
        }
        public static (User _loginUser,bool _isLogin) IsUserLogInputCorrectly(string _email, string _password)
        {
            return (SignedUsers.Where(x=> x.EMail == _email && x.Password == _password).SingleOrDefault(), SignedUsers.Any(x => x.EMail == _email && x.Password == _password));
        }
        public static void UserLoginQuestion()
        {
            Console.WriteLine("Giriş için 'E' \n Menüye dönmek için 'H'");
        }
        public static void UserLoginLibrary()
        {
            Program.ConsoleClearingWaiting(3);
            Console.WriteLine($"Coders Life Kütüphanesine Hoş Geldiniz.");
            Program.SystemWaiting(1);
            int step = 0;
        main:
            step++;
            Console.WriteLine("Giriş için Lütfen Email ve Şifrenizi giriniz.");
            Console.Write("Email: ");
            string _email = Console.ReadLine();
            Console.Write("Password: ");
            string _password = Console.ReadLine();
            (User _loginUser,bool isLogin) = IsUserLogInputCorrectly(_email, _password);
            if (isLogin)
            {
                CurrentUser = _loginUser;
                Console.WriteLine("Giriş bilgileriniz doğru! Bilgileriniz yükleniyor...");
                Program.SystemWaiting(1);
                Program.ConsoleClearingWaiting(5);
                ShowUserProfil(_loginUser);
            }
            else
            {
                if (step == 3)
                {
                    Console.WriteLine("Ard Arda çok fazla başarısız giriş... Menuye yönlendiriliyorsunuz");
                    Program.SystemWaiting(1);
                    Program.ConsoleClearingWaiting(3);
                    Program.GoMenu();
                    return;
                }
                Console.WriteLine("Bilgileriniz eksik veya hatalı, Lütfen tekrar deneyiniz.");
                Program.SystemWaiting(1);
                Program.ConsoleClearingWaiting(2);
                goto main;
            }
            
        }
        public static void ShowUserProfil(User _loginUser)
        {
            Console.WriteLine($"-------------[{_loginUser.Name}]-------------");
            Console.WriteLine($"E-Mail => {_loginUser.EMail}");
            Console.WriteLine($"Password => {_loginUser.Password}");
            foreach (var item in _loginUser.GetMyLibraryBooks())
            {
                Console.WriteLine(item._Book.Author + " " + item._PurchaseDate.ToString());
            }
        }
    }
}
