﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08022024_LibraryApplication_HobbyProject
{
    public class User
    {
        public int ID;
        public string Name;
        public string EMail;
        public string Password;
        List<(Book _Book, DateTime _PurchaseDate)> LibraryBooks = new List<(Book _Book, DateTime _PurchaseDate)>();
        public User(int _id, string _name, string _email, string _password) 
        { 
            ID = _id;
            Name = _name;
            EMail = _email;
            Password = _password;
        }
        public void AddMyLibraryBook(Book _book)
        {
            LibraryBooks.Add((_book,DateTime.Now));
        }
        public List<(Book _Book, DateTime _PurchaseDate)> GetMyLibraryBooks()
        {
            return LibraryBooks;
        }
        public void RemoveMyLibraryBook(Book _book)
        {
            LibraryBooks.Remove(LibraryBooks.Where(x=> x._Book.ID == _book.ID).SingleOrDefault());
        }
        public DateTime GetMyBookPurchaseDate(Book _book)
        {
            return LibraryBooks.Where(x => x._Book.ID == _book.ID).SingleOrDefault()._PurchaseDate;
        }
    }
}
