﻿namespace _20122023_TryParseDetailLearning_HobbyProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            TryParseControl();
        }
        public static void TryParseControl()
        {
            string value = Console.ReadLine();
            if (int.TryParse(value,out int result))
            {
                Console.WriteLine(result.ToString());
            }
            else
            {
                Console.WriteLine("Giriş Başarısız: Lütfen Bir Sayı Giriniz.");
            }
        }
    }
}
