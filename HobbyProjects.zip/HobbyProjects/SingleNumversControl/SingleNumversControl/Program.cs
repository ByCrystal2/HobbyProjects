﻿namespace SingleNumversControl
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
        public void Nums(int[] _nums)
        {
            int length = _nums.Length;
            int correctNum = 0;
            for (int i = 0; i < length; i++)
            {
                int a = _nums[i + 1] - _nums[i];
                if (a % 2 != 0)
                {
                    correctNum = a;
                }
            }
        }
    }
}
