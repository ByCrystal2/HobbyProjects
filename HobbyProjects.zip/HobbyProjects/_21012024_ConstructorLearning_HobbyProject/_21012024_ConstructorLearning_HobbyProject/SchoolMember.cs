﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21012024_ConstructorLearning_HobbyProject
{
    internal class SchoolMember
    {
    }
}
