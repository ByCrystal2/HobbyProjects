﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21012024_ConstructorLearning_HobbyProject
{
    public static class SchoolManager
    {
        public static List<Mudur> Mudurler = new List<Mudur>();
        public static void Init()
        {
            MudurInitilation();
        }
        public static void MudurInitilation()
        {
            Mudurler.Clear();
            Mudur m1 = new Mudur(0, "Ahmet Burak", 45, DateTime.Now, Branches.Matematik);
            Mudur m2 = new Mudur(1, "Fatma Gül Burak", 50, DateTime.Now, Branches.Felsefe);
            Mudur m3 = new Mudur(2, "Kel Mahmut", 60, DateTime.Now, Branches.Fizik);

            Mudurler.Add(m1);
            Mudurler.Add(m2);
            Mudurler.Add(m3);
        }
        public static void AddSchools()
        {
            Random r = new Random();
            int randomCount = r.Next(0, Mudurler.Count);
            Mudur myMudur = Mudurler[randomCount];



            School s1 = new School(0, "Eleşkirt Anadolu Lisesi", myMudur,);
            myMudur.SchoolAssign(s1.SchoolName);
            
        }
        
    }
    public enum Branches
    {
        None,
        Matematik,
        Fizik,
        Turkce,
        Ingilizce,
        Kimya,
        Biyoloji,
        DinKulturu,
        Beden,
        SosyalBilgiler,
        Cografya,
        Tarih,
        Felsefe
    }
    public enum SchoolSection
    {
        None,
        Sayisal,
        Sozel,
        EsitAgirlik,
        Dil
    }
    public enum SchoolLetter
    {
        None,
        A,
        B,
        C,
        D,
        E
    }
    
    public class SchoolCellNumber
    {
        public SchoolLetter SL;
        public int SN;
        public SchoolCellNumber(SchoolLetter _schoolLetter, int _schoolNumber)
        {
            this.SL = _schoolLetter;
            this.SN = _schoolNumber;
        }
    }
}
