﻿namespace _21012024_ConstructorLearning_HobbyProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1. Yol
            Mudur m1 = new Mudur();
            m1.ID = 0;
            m1.FullName = "Kel Ahmet";
            m1.Age = 50;
            m1.CurrentSchool = "Osmaniye Cebeli Bereket Anadolu Lisesi";
            m1.YearInOffice = new DateTime(2015, 12, 31);

            //2. Yol (Constructor)
            Mudur m2 = new Mudur(1,"Kel Mahmut", 31, new DateTime(2018,12,8,10,31,31), "Eleşkirt Anadolu Lisesi", Branches.Biyoloji);

            Console.WriteLine($"{m1.FullName} Adlı Müdür, {m1.CurrentSchool} Adlı okulda, {m1.TimeInOffice} Süredir görev yapmaktadır.");
            Console.WriteLine($"{m2.FullName} Adlı Müdür, {m2.CurrentSchool} Adlı okulda, {m2.TimeInOffice} Süredir görev yapmaktadır.");


        }
    }
}
