﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21012024_ConstructorLearning_HobbyProject
{
    public class School
    {
        public int ID;
        public string SchoolName;
        public Mudur mudur;
        public List<MudurYardimcisi> mudurYardimcilari = new List<MudurYardimcisi>();
        public List<Ogretmen> Ogretmenler = new List<Ogretmen>();
        public List<Memur> Memurlar = new List<Memur>();
        public List<Personel> Personeller = new List<Personel>();
        public List<Ogrenci> Ogrenciler = new List<Ogrenci>();
        public SchoolType MySchoolType;

        public School(int _id, string _schoolName, Mudur _m, List<MudurYardimcisi> _mys, List<Ogretmen> _os, List<Memur> _memurs, List<Personel> _ps, List<Ogrenci> _ogrenciler, SchoolType _st)
        {
            this.mudur = _m;

            mudurYardimcilari.Clear();
            List<MudurYardimcisi> myler = new List<MudurYardimcisi>();
            int length = _mys.Count;
            for (int i = 0; i < length; i++)
            {
                myler.Add(_mys[i]);
            }
            this.mudurYardimcilari = myler;

            Ogretmenler.Clear();
            List<Ogretmen> ogler = new List<Ogretmen>();
            int length1 = _os.Count;
            for (int i = 0; i < length1; i++)
            {
                ogler.Add(_os[i]);
            }
            this.Ogretmenler = ogler;

            Memurlar.Clear();
            List<Memur> memurlar = new List<Memur>();
            int length2 = _memurs.Count;
            for (int i = 0; i < length2; i++)
            {
                memurlar.Add(_memurs[i]);
            }
            this.Memurlar = memurlar;

            Personeller.Clear();
            List<Personel> personeller = new List<Personel>();
            int length3 = _ps.Count;
            for (int i = 0; i < length3; i++)
            {
                personeller.Add(_ps[i]);
            }
            this.Personeller = personeller;

            Ogrenciler.Clear();
            List<Ogrenci> ogrenciler = new List<Ogrenci>();
            int length4 = _ogrenciler.Count;
            for (int i = 0; i < length4; i++)
            {
                ogrenciler.Add(_ogrenciler[i]);
            }
            this.Ogrenciler = ogrenciler;

            this.MySchoolType = _st;
        }
    }
    public enum SchoolType
    {
        None,
        IlkOkul,
        OrtaOkul,
        Lise,
        Universite
    }
}
