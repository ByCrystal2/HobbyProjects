﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21012024_ConstructorLearning_HobbyProject
{
    public class Ogrenci
    {
        public int ID;
        public string FullName;
        public int Age;
        public DateTime YearInSchool;
        public string CurrentSchool;
        public SchoolCellNumber MySchoolRoomNumber;

        public DateTime TimeInSchool;
        public Ogrenci(int _id, string _fullName, int _age, DateTime _yearInSchool, string _currentSchool, SchoolLetter _sl, int _schoolNumber)
        {
            this.ID = _id;
            this.FullName = _fullName;
            this.Age = _age;
            this.YearInSchool = _yearInSchool;

            int year = DateTime.Now.Year;
            int year1 = YearInSchool.Year;

            int month = DateTime.Now.Month;
            int month1 = YearInSchool.Month;

            int day = DateTime.Now.Day;
            int day1 = YearInSchool.Day;
            TimeSpan s = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            TimeSpan s1 = new TimeSpan(_yearInSchool.Hour, _yearInSchool.Minute, _yearInSchool.Second);

            this.TimeInSchool.AddYears(year - year1);
            this.TimeInSchool.AddMonths(month - month1);
            this.TimeInSchool.AddDays(day - day1);
            this.TimeInSchool.AddHours(s.Hours - s1.Hours);
            this.TimeInSchool.AddMinutes(s.Minutes - s1.Minutes);
            this.TimeInSchool.AddSeconds(s.Seconds - s1.Seconds);

            this.CurrentSchool = _currentSchool;
            this.MySchoolRoomNumber = new SchoolCellNumber(_sl, _schoolNumber);
        }
    }
}
