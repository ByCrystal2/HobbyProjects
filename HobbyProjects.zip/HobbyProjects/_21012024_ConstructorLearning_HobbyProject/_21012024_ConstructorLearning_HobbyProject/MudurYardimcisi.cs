﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21012024_ConstructorLearning_HobbyProject
{
    public class MudurYardimcisi
    {
        public int ID;
        public string FullName;
        public int Age;
        public DateTime YearInOffice;
        public string CurrentSchool;
        public Branches MyBranch;

        public DateTime TimeInOffice;
        public MudurYardimcisi(int _id, string _fullName, int _age, DateTime _yearInOffice, string _currentSchool, Branches _branch)
        {
            this.ID = _id;
            this.FullName = _fullName;
            this.Age = _age;
            this.YearInOffice = _yearInOffice;

            int year = DateTime.Now.Year;
            int year1 = _yearInOffice.Year;

            int month = DateTime.Now.Month;
            int month1 = _yearInOffice.Month;

            int day = DateTime.Now.Day;
            int day1 = _yearInOffice.Day;
            TimeSpan s = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            TimeSpan s1 = new TimeSpan(_yearInOffice.Hour, _yearInOffice.Minute, _yearInOffice.Second);

            this.TimeInOffice.AddYears(year - year1);
            this.TimeInOffice.AddMonths(month - month1);
            this.TimeInOffice.AddDays(day - day1);
            this.TimeInOffice.AddHours(s.Hours - s1.Hours);
            this.TimeInOffice.AddMinutes(s.Minutes - s1.Minutes);
            this.TimeInOffice.AddSeconds(s.Seconds - s1.Seconds);

            this.CurrentSchool = _currentSchool;
            this.MyBranch = _branch;
        }
    }
}
