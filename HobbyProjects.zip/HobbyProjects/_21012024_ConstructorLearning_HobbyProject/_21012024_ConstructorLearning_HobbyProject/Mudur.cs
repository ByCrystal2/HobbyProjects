﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;

namespace _21012024_ConstructorLearning_HobbyProject
{
    public class Mudur
    {
        public int ID;
        public string FullName;
        public int Age;
        public DateTime YearInOffice;
        public string CurrentSchool;
        public Branches MyBranch;

        public DateTime TimeInOffice;       
        public Mudur(int _id, string _fullName, int _age, DateTime _yearInOffice, Branches _branch)
        {
            this.ID = _id;
            this.FullName = _fullName;
            this.Age = _age;
            this.YearInOffice = _yearInOffice;

            int year = DateTime.Now.Year;
            int year1 = _yearInOffice.Year;
            

            int month = DateTime.Now.Month;
            int month1 = _yearInOffice.Month;
            int MonthResult = (month - month1);
            if (month - month1 < 0)
            {
                MonthResult = -(month - month1);
            }

            int day = DateTime.Now.Day;
            int day1 = _yearInOffice.Day;
            int DayResult = (day - day1);
            if (day - day1 < 0)
            {
                DayResult = -(day - day1);
            }
            TimeSpan s = new TimeSpan(DateTime.Now.Hour);
            TimeSpan s1 = new TimeSpan(_yearInOffice.Hour);
            int HourResult = (s.Hours - s1.Hours);
            if (s.Hours - s1.Hours < 0)
            {
                HourResult = -(s.Hours - s1.Hours);
            }
            this.TimeInOffice.AddYears(year - year1);
            this.TimeInOffice.AddMonths(MonthResult);
            this.TimeInOffice.AddDays(day - day1);
            this.TimeInOffice.AddHours(s.Hours - s1.Hours);

            this.MyBranch = _branch;
        }
        public void SchoolAssign(string _SchoolName)
        {
            this.CurrentSchool = _SchoolName;
        }
    }

}
